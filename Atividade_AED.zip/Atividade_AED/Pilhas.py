# Desenvolva o exercício solicitado no slide da aula 13 - Pilha, considerando que a classe Livro
# tem os atributos título: String, autor: String, páginas: int e próximo: Livro. A classe Pilha 
# tem os atributos topo: Livro, tamanho: int e os métodos add( l: Livro ), remover() e imprimir().


class PilhaDeLivros:
    def __init__(self):
        self.pilha = []

    def adicionar(self, livro):
        self.pilha.append(livro)
        print(f'O livro "{livro}" foi adicionado à pilha.')

    def remover(self):
        if self.esta_vazia():
            print("A pilha está vazia. Nenhum livro para remover.")
            return None
        livro_removido = self.pilha[-1]
        self.pilha = self.pilha[:-1]
        print(f'Livro "{livro_removido}" removido da pilha.')
        return livro_removido


    def ver_topo(self):
        if self.esta_vazia():
            print("A pilha está vazia.")
            return None
        return self.pilha[-1]

    def esta_vazia(self):
        return len(self.pilha) == 0

    def contar(self):
        return len(self.pilha)

def menu_principal():
    pilha = PilhaDeLivros()
    while True:
        print("\nMenu de Opções:")
        print("1. Inserir livro")
        print("2. Retirar livro")
        print("3. Consultar livro no topo")
        print("4. Verificar se a pilha está vazia")
        print("5. Ver quantidade de livros na pilha")
        print("6. Encerrar")
        escolha = input("Escolha uma opção: ")

        if escolha == '1':
            livro = input("Digite o nome do livro para adicionar: ")
            pilha.adicionar(livro)
        elif escolha == '2':
            pilha.remover()
        elif escolha == '3':
            topo = pilha.ver_topo()
            if topo:
                print(f'Livro no topo da pilha: "{topo}"')
        elif escolha == '4':
            if pilha.esta_vazia():
                print("A pilha está vazia.")
            else:
                print("A pilha contém livros.")
        elif escolha == '5':
            print(f'Total de livros na pilha: {pilha.contar()}')
        elif escolha == '6':
            print("Encerrando...")
            break
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    menu_principal()